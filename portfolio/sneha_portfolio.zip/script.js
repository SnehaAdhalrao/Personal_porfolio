var typed = new Typed('#element', {
    strings: ['Learner', 'Developer'],
    typeSpeed: 50,
    loop: true
});